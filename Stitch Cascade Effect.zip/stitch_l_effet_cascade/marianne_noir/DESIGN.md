# Command Center Dark

## Visual Narrative
This design system is built for high-stakes, institutional interfaces where authority and precision are paramount. By utilizing a deep navy blue and a stark red against a near-black background, the system creates a high-contrast environment that demands attention while maintaining professional rigor. The aesthetic is "Subtle Industrial"—sharp enough for technical data but refined enough for executive reporting.

## Core Principles
- **Authoritative Contrast**: Utilizing pure whites and vibrant reds against a deep neutral base ensures critical information is never missed.
- **Controlled Density**: A balanced spatial rhythm ensures that complex data layouts remain legible without feeling cramped or overly airy.
- **Geometric Precision**: A focus on subtle corner radii and clean, sans-serif typography reflects a commitment to technical accuracy.

## Foundation

### Color Palette
- **Primary (Blue - #000091)**: The core brand color, used for primary actions and institutional identification.
- **Secondary (Red - #E1000F)**: Reserved for high-priority alerts, critical actions, and dynamic indicators.
- **Tertiary (White - #FFFFFF)**: Used for high-contrast accents, iconography, and decorative highlights.
- **Neutral (#050505)**: A deep, midnight base that provides a flicker-free environment for extended use in dark settings.

### Typography
- **Headlines**: **Public Sans** — A geometric, neutral typeface that provides a clean, institutional feel for headers.
- **Body & Labels**: **Inter** — Optimized for readability on screens, ensuring that dense data and technical labels are easily parsed.

### Shape & Space
- **Roundedness (1)**: Subtle rounded corners provide a modern touch without sacrificing the "serious" nature of the interface. It maintains an organized, modular appearance.
- **Spacing (2)**: A standard, "Normal" spacing scale. This transition from compact to balanced spacing provides enough room for visual breathing while still allowing for the information density required in dashboard-heavy applications.

## Component Strategy
- **Buttons**: High-visibility Primary Blue with sharp-ish corners (Radius 1).
- **Surface Elevation**: Subtle shifts in the neutral scale are used to distinguish between background layers and active panels.
- **Information Density**: The Normal spacing configuration allows for a comfortable reading experience in both mobile and desktop contexts.