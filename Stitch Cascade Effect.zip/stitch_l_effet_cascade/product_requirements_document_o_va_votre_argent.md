# PRD: "Où va votre argent ?" — Simulateur Fiscal Freelance

## Project Overview
A premium fiscal simulator for French freelancers and employees to visualize the journey of gross revenue to net take-home pay across multiple legal statuses.

## Target Audience
- Freelancers (Micro-entreprise, EI, EURL, SASU, Holding)
- Employees (CDI, Portage salarial)
- Career switchers comparing statuses

## Visual Identity & Tone
- **Tone:** Educational, empowering, transparent, satisfying.
- **Style:** Dark mode, monochrome base, premium fintech aesthetic.
- **Color Strategy:** 
    - Monochrome interface.
    - Status-specific color identities for easy distinction.
    - High-contrast accents for key figures (Net en poche).
- **Typography:** Technical, precise, monospace for monetary values.
- **Formatting:** French currency formatting (e.g., "48 700 €").

## Core Feature: The Cascade
A visual flow showing:
`Chiffre d'affaires HT` → `Cotisations sociales` → `Impôt sur le revenu` → `Net en poche`.
The visual weight of each step should be proportional to its financial impact.

## Screen Requirements
1. **Entry Point:** Choice between Salarié, Indépendant, or Comparison.
2. **Main Simulator:** Real-time updates with revenue slider, status switching, and the Cascade visualization.
3. **Comparison View:** Side-by-side analysis of all statuses with deltas vs. CDI.
4. **Detail Views:** Breakdowns for social contributions, retirement impact, and corporate tax strategy.
5. **Mobile Version:** Optimized for vertical flow.

## Interactions
- Smooth transitions and animated numbers.
- Real-time reactivity to parameter changes.
- "Alive" but focused feel.

## Language
- French (UI labels, legal terms).
- Disclaimer: "Barème officiel 2026 · Simulateur à but pédagogique".