```markdown
# Design System Document: Institutional Modernism

## 1. Overview & Creative North Star
### The Creative North Star: "The Sovereign Ledger"
This design system is built to evoke the weight, authority, and precision of a state-level institution while maintaining the agility of a modern financial entity. We are moving away from "app-like" interfaces and toward a "Digital Editorial" experience. 

The aesthetic is **Institutional Modernism**. It rejects the playful roundness of consumer tech in favor of architectural purity: sharp 0px corners, intentional asymmetry, and a rigorous adherence to whitespace. We do not use lines to separate ideas; we use the "physics of paper"—layering tones and depths to guide the eye. Every pixel must feel like it was placed by a cartographer.

---

## 2. Colors: High-Contrast Authority
The palette is rooted in the Tricolour heritage but elevated through digital-first tonal ranges.

### Core Palette
- **Primary (#000091):** The "State Blue." Used for navigation, primary actions, and branding. It represents the foundation of the system.
- **Secondary (#BC000A):** The "Precision Red." Used sparingly for critical alerts, accents, and high-importance data points.
- **Surface (#F9F9F9):** The "Document Base." A clean, off-white that feels more like premium paper than a cold screen.

### The "No-Line" Rule
Standard 1px borders are strictly prohibited for sectioning or containment. We define boundaries through **Background Tonal Shifts**.
- To separate a sidebar from a main feed, transition from `surface` to `surface-container-low`.
- To highlight a section, place a `surface-container-lowest` element on a `surface-container-high` background.

### Signature Textures & Glass
To prevent the "Institutional" look from feeling "Flat," use these techniques:
- **Primary CTAs:** Use a subtle linear gradient from `primary` (#000053) to `primary-container` (#000091) at a 135° angle. This adds a "silk" finish to buttons.
- **Glassmorphism:** Use for floating navigation headers. Apply `surface` at 80% opacity with a `20px` backdrop blur. This allows content to "ghost" beneath the navigation, creating a sense of infinite depth.

---

## 3. Typography: Editorial Clarity
We use **Inter** (as a modern proxy for Marianne) to achieve a look that is both official and accessible.

- **Display (Large/Medium):** Used for "Statement" hero sections. These should be set with slightly tighter tracking (-0.02em) to feel like a printed broadsheet.
- **Headlines:** Use `headline-lg` for section headers. Ensure there is significant vertical whitespace (48px+) above headlines to let the "document" breathe.
- **Body Text:** Set `body-lg` with a generous line-height (1.6) for maximum legibility in dense financial reports.
- **Labels:** Always in uppercase with +0.05em letter spacing when used for metadata or category tags.

---

## 4. Elevation & Depth: The Layering Principle
We do not use traditional drop shadows to create "lift." We use **Tonal Layering** to create "stacking."

- **The Stack:** 
    1. Base Level: `surface`
    2. Content Blocks: `surface-container-low`
    3. Interactive Cards: `surface-container-lowest`
- **Ambient Shadows:** Only for truly floating elements (modals, tooltips). Use an extra-diffused shadow: `box-shadow: 0px 24px 48px rgba(0, 0, 83, 0.06);`. The shadow is tinted with our Primary Blue to feel like natural ambient light, never neutral grey.
- **Sharpness:** All `border-radius` tokens are set to **0px**. This is non-negotiable. The authority of the system comes from its rigid, architectural corners.

---

## 5. Components: Precision Instruments

### Buttons
- **Primary:** 0px corners, Primary-to-Primary-Container gradient. White text.
- **Secondary:** Transparent background with a "Ghost Border" (outline-variant at 20% opacity).
- **States:** On hover, the background should shift one tier darker (e.g., from `primary` to `on-primary-fixed-variant`).

### The 'Avertissement' (Institutional Notice)
The non-government disclaimer must look like a legal seal, not a warning.
- **Style:** A full-width `surface-container-highest` block.
- **Typography:** `label-md` in `on-surface-variant`.
- **Accent:** A 4px vertical "accent bar" of `secondary` (Red) on the far left. This signals importance without the "danger" of a standard error box.

### Data Visualization
- **Line Charts:** Use `primary` for the main data line. Use a `secondary` (Red) dot only for the "Current Value" or "Peak."
- **Grid Lines:** Use `outline-variant` at 10% opacity. If the data is clear without lines, omit them entirely.

### Input Fields
- **Style:** "Underline Only" or "Block Fill." Do not use 4-sided boxes. 
- **States:** Focus state is indicated by a 2px `primary` bottom border and a subtle shift to `surface-container-highest`.

### Cards
- **Forbid Dividers:** Use 24px or 32px of vertical padding to separate content within a card.
- **Selection:** Indicated by a `secondary` (Red) 4px border-left, never a color change of the entire card.

---

## 6. Do's and Don'ts

### Do
- **Do** embrace asymmetry. A wider left margin than right margin can make a dashboard feel like a bespoke financial report.
- **Do** use `primary-fixed-dim` for background elements that need to feel "recessed."
- **Do** ensure all data visualizations are accessible; use patterns or high-contrast tonal shifts in addition to color.

### Don't
- **Don't use any border-radius.** Even a 2px radius breaks the "Institutional Modernism" architecture.
- **Don't use standard icons.** Use thin-stroke (1px or 1.5px) geometric icons that match the sharpness of the typography.
- **Don't use "Grey."** Every "Neutral" in this system is slightly tinted with Blue (`primary`) to maintain a cohesive brand temperature. 100% neutral greys will look "dirty" against the French State Blue.

---

## 7. Signature Layout: The "Editorial Grid"
When designing pages, avoid the standard 12-column center-aligned grid. Instead:
1. **The Lead:** Place the most critical data point in a large `display-lg` font in the top-left quadrant.
2. **The Context:** Use a 3-column wide "Avertissement" block to the right of the lead to balance the weight.
3. **The Data:** Use "Negative Space" to group metrics. If two metrics are related, place them on the same tonal background. If they are different, change the background tone behind them.